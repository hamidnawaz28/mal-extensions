import { Box } from '@mui/material'

// import Browser from 'webextension-polyfill';

const ContentScript = () => {
  return (
    <Box
      sx={{
        paddingLeft: '2%',
        paddingY: '5px',
        backgroundColor: 'white',
      }}
    ></Box>
  )
}

export default ContentScript
