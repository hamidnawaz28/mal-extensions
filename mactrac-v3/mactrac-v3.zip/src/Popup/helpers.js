// import Browser from 'webextension-polyfill';
// Browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
//   if (request.action === 'getAds') {
//     const ads = extractAdData();
//     sendResponse({ success: true, ads });
//   }
//   return true;
// });
