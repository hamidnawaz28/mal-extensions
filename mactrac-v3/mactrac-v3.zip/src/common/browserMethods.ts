import Browser from 'webextension-polyfill'
import { asyncSleep } from './utils'

const syncRef = Browser.storage.sync
const localRef = Browser.storage.local

async function setSyncStorage(KEY: string, data: any) {
  await syncRef.set({ [KEY]: data })
}

async function setLocalStorage(KEY: string, data: any) {
  await localRef.set({ [KEY]: data })
}

async function getSyncStorage(KEY: string) {
  const data = await syncRef.get()
  return data[KEY]
}

async function getLocalStorage(KEY: string) {
  const data = await localRef.get()
  return data[KEY]
}

async function sendActiveTabMesage(data: any) {
  const activeTab = await activeTabData()
  return await Browser.tabs.sendMessage(activeTab.id, { ...data })
}

async function sendTabMesageWithId(tabId: number, data: any) {
  return await Browser.tabs.sendMessage(tabId, { ...data })
}

async function runTimeMessage(data: any) {
  return await Browser.runtime.sendMessage(data)
}

async function reloadATab(tabId: number) {
  await Browser.tabs.reload(tabId)
}

async function createATab(url: string) {
  return await Browser.tabs.create({ url })
}

async function updateATabUrl(tabId: number, url: string, wait = false) {
  await Browser.tabs.update(tabId, { url })
  wait ? await waitTillTabLoads(tabId) : null
}

async function updateActiveTabUrl(url: string, wait = false) {
  const activeTab = await activeTabData()
  const activeTabId = activeTab.id
  await Browser.tabs.update(activeTabId, { url })
  wait ? await waitTillTabLoads(activeTabId) : null
}

async function waitTillActiveTabLoads() {
  const activeTab = await activeTabData()
  const activeTabId = activeTab.id
  await waitTillTabLoads(activeTabId)
}

async function waitTillTabLoads(tabId: number) {
  await asyncSleep(0.5)
  const tab = await Browser.tabs.get(tabId)
  if (tab.status == 'loading') {
    await waitTillTabLoads(tabId)
  } else return
}

async function activeTabData() {
  const tabsData: any = await Browser.tabs.query({
    active: true,
  })
  return tabsData[0]
}

export {
  setLocalStorage,
  getLocalStorage,
  setSyncStorage,
  getSyncStorage,
  sendActiveTabMesage,
  sendTabMesageWithId,
  runTimeMessage,
  reloadATab,
  createATab,
  updateATabUrl,
  activeTabData,
  updateActiveTabUrl,
  waitTillTabLoads,
  waitTillActiveTabLoads,
}
